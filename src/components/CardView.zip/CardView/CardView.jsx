import React, { Component } from 'react';
import './cardview.css';
import whiteArrow from '../../components/images/whiteArrow.png';
class CardView extends Component {
    state = {}
    render() {
        return (
            <div className={"cardViewContainer " + this.props.className}>
                <div className="cardImage">
                    <img src={this.props.imgSRC} alt="" />
                </div>
                <div className="cardBottomContainer">
                    <div className="cardText">
                        <div>Jhons warehouse</div>
                        <div>Maharashtra</div>
                    </div>
                    <div className="rightArrowContainer">
                        <div className="rightButton">
                            <img src={whiteArrow} alt="" />
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default CardView;